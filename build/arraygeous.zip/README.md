# arraygeous
A JavaScript library for lightning fast Array manipulation. [![Build Status](https://travis-ci.org/HarryStevens/arraygeous.svg?branch=master)](https://travis-ci.org/HarryStevens/arraygeous)

Functions:
- includes
- random
- sum
- unique